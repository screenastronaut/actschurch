<?php
	_deprecated_file( __FILE__, '3.10', 'Tribe__Events__Pro__Widgets' );


	class TribeEventsPro_Widgets extends Tribe__Events__Pro__Widgets {

	}