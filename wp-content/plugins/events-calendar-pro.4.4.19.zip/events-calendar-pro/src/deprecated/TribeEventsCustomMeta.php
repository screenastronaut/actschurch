<?php
	_deprecated_file( __FILE__, '3.10', 'Tribe__Events__Pro__Custom_Meta' );


	class TribeEventsCustomMeta extends Tribe__Events__Pro__Custom_Meta {

	}