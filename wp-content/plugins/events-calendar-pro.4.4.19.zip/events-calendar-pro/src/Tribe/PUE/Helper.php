<?php

class Tribe__Events__Pro__PUE__Helper {

	/**
	 * @var string Helper data
	 */
	const DATA = 'e2e76be2eaa4e172f6b5389abaf94038c333f743';

}
