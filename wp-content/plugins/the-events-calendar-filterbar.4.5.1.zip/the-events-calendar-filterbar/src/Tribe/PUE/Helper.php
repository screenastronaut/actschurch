<?php

class Tribe__Events__Filterbar__PUE__Helper {

	/**
	 * @var string Helper data
	 */
	const DATA = '5bef993e5b825d72b79c0b77e11df4fddf3f314e';

}
