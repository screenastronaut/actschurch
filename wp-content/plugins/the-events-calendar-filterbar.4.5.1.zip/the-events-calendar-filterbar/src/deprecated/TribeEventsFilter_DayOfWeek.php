<?php
	_deprecated_file( __FILE__, '3.10', 'Tribe__Events__Filterbar__Filters__Day_Of_Week' );


	class TribeEventsFilter_DayOfWeek extends Tribe__Events__Filterbar__Filters__Day_Of_Week {

	}