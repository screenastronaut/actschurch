<?php
	_deprecated_file( __FILE__, '3.10', 'Tribe__Events__Filterbar__Filters__Time_Of_Day' );


	class TribeEventsFilter_TimeOfDay extends Tribe__Events__Filterbar__Filters__Time_Of_Day {

	}