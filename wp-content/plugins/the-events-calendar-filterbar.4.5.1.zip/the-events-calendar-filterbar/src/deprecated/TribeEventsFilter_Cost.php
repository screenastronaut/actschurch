<?php
	_deprecated_file( __FILE__, '3.10', 'Tribe__Events__Filterbar__Filters__Cost' );


	class TribeEventsFilter_Cost extends Tribe__Events__Filterbar__Filters__Cost {

	}